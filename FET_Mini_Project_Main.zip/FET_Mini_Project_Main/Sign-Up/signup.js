$(document).ready(function () {
    //hide and show profession/artform
    $('input[name="role"]').click(function () {
        var test = $(this).val();
        if (test === "Artist") {
            $("#profession,#L_profession").css("display", "none");
            $("#artform,#L_artform").css("display", "block");
        }
        if (test === "User") {
            $("#artform,#L_artform").css("display", "none");
            $("#profession,#L_profession").css("display", "block");
        }

    })
    //validate User Type
    function validateUserType() {
        if ($('input[name="role"]:checked').length != 0) {
            return true;
        }
        else {
            alert('please select User Type');
            return false;
        }
    }

    //validate Name
    function validateName() {
        if ($('#name').val().length == "") {
            alert('please enter valid Name');
            return false;
        }
        else {
            return true;
        }
    }

    //validate Email
    function validateEmail() {
        var pattern = /^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/;
        let email = $('#email').val();
        if (pattern.test(email)) {
            return true;
        }
        else {
            alert('please enter valid Email');
            return false;
        }
    }

    //validate ArtForm
    function validateArtForm() {
        let email = $('#email').val();
        if (email.length == "") {
            alert('please enter valid Email');
            return false;
        }
        else {
            return true;
        }
    }

    //validate Profession
    function validateProfession() {
        if ($('#profession').val().length == "") {
            alert('please enter valid Profession');
            return false;
        }
        else {
            return true;
        }
    }

    //validate Contact
    function validateContact() {
        let num = /^\d{10}$/;
        let ipNum = $('#contact_no').val();
        if (num.test(ipNum)) {
            return true;
        }
        else {
            alert('please enter valid Contact Number');
            return false;
        }
    }

    //validate Gender
    function validateGender() {
        if ($('input[name="gender"]:checked').length != 0) {
            return true;
        }
        else {
            alert('please select Gender');
            return false;
        }
    }

    //validate Address
    function validateAddress() {
        if ($('#address').val().length == "") {
            alert('please enter valid Address');
            return false;
        }
        else {
            return true;
        }
    }

    //validate Password
    function validatePassword() {
        if ($('#password').val().length == "") {
            alert('please enter valid Password');
            return false;
        }
        else {
            return true;
        }
    }

    //validate CPassword
    function validateCPassword() {
        if ($('#Cpassword').val() != $('#password').val()) {
            alert('please enter valid Password');
            return false;
        }
        else {
            return true;
        }
    }


    $("#submit").click(function (e) {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();

        if (validateUserType() && validateName() && validateEmail() && validateContact() && validateGender() && validateAddress() && validatePassword() && validateCPassword()) {
            if ($('input[name="role"]:checked').val() === "Artist") {
                $.post("http://localhost:3000/Artist", {
                    Role: $('input[name="role"]:checked').val(),
                    Name: $("#name").val(),
                    Email: $("#email").val(),
                    Art_Form: $("#artform").val(),
                    Contact_No: $("#contact_no").val(),
                    Gender: $('input[name="gender"]:checked').val(),
                    Address: $("#address").val(),
                    Password: $("#password").val(),
                    C_Password: $("#Cpassword").val(),
                    Profile_Pic: $("#profile_pic").val()//actualPath//imgPath 

                })
            } else {
                $.post("http://localhost:3000/User", {
                    Role: $('input[name="role"]:checked').val(),
                    Name: $("#name").val(),
                    Email: $("#email").val(),
                    Profession: $("#profession").val(),
                    Contact_No: $("#contact_no").val(),
                    Gender: $('input[name="gender"]:checked').val(),
                    Address: $("#address").val(),
                    Password: $("#password").val(),
                    C_Password: $("#Cpassword").val(),
                    Profile_Pic: $("#profile_pic").val()//actualPath//imgPath
                })
            }
        } else {
            alert('Something Went Wrong...Please Try Again');
        }

    });

    // $("#b2").click(function() {
    //     location.href =  "index.html";
    // });
    // , "http://localhost:3000/User", {
    //         Profile_Pic: img,
    //     }
}
)